import Tareas from './components/Tareas'
import { useState } from 'react'
import './App.css'

function App() {
  return (
    <>
      <Tareas />
    </>
  )
}

export default App
