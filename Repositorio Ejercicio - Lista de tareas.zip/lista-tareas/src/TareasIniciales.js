export const tareasIniciales = [
    {
      nombre: "Tarea 1",
      completada: false,
    },
    {
      nombre: "Tarea 2",
      completada: false,
    },
    {
      nombre: "Tarea 3",
      completada: true,
    }
]
